<?php
namespace Rasik\ReCaptcha\Block\Captcha;
class Captcha extends \Magento\Framework\View\Element\Template
{
	protected $helper;
	public function __construct(\Magento\Framework\View\Element\Template\Context $context,
		                         \Rasik\ReCaptcha\Helper\Data $helper
	                            )
	{
		parent::__construct($context);
		$this->helper = $helper;
	}

	public function isEnabled()
	{
		return $this->helper->isEnabled();
	}
	public function getSiteKey()
	{
		return $this->helper->getSiteKey();
	}
	
}